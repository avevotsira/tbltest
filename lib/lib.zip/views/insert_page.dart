import 'package:flutter/material.dart';
import '../services/remote_service.dart';
import '../views/home_page.dart';
class InsertPage extends StatefulWidget {
  const InsertPage({Key? key}) : super(key: key);

  @override
  State<InsertPage> createState() => _InsertPageState();
}

class _InsertPageState extends State<InsertPage> {
  final _productNameCtrl = TextEditingController();
  final _productPriceCtrl = TextEditingController();
  final _productPhotoCtrl = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('New product'),
        leading: new IconButton(
          icon: new Icon(Icons.ac_unit),
          //onPressed: () => Navigator.of(context).pop(),
          onPressed: (){
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => HomePage()));
          },
        ),
      ),

      body: Center(
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              TextField(
                controller: _productNameCtrl,
                decoration: InputDecoration(hintText: 'Name'),
              ),
              TextField(
                controller: _productPriceCtrl,
                decoration: InputDecoration(hintText: 'Price'),
                keyboardType: TextInputType.number,
              ),
              TextField(
                controller: _productPhotoCtrl,
                decoration: InputDecoration(hintText: 'Photo'),
              ),
              RaisedButton(
                child: Text(
                  'SAVE',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
                color: Colors.purple,
                onPressed: () {
                  final body = {
                    "name": _productNameCtrl.text,
                    "price": _productPriceCtrl.text,
                    "photo": _productPhotoCtrl.text,
                  };
                  RemoteService.addProduct(body).then((success) {
                    if (success) {
                      showDialog(
                        builder: (context) => AlertDialog(
                          title: Text('Data added!!!'),
                          actions: <Widget>[
                            FlatButton(
                              onPressed: () {
                                Navigator.pop(context);
                                _productNameCtrl.text = '';
                                _productPriceCtrl.text = '';
                                _productPhotoCtrl.text = '';
                              },
                              child: Text('OK'),
                            )
                          ],
                        ),
                        context: context,
                      );
                      return;
                    }else{
                      showDialog(
                        builder: (context) => AlertDialog(
                          title: Text('Error Adding!!!'),
                          actions: <Widget>[
                            FlatButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: Text('OK'),
                            )
                          ],
                        ),
                        context: context,
                      );
                      return;
                    }
                  });
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
