import 'package:flutter/material.dart';
import '../services/remote_service.dart';
import '../views/home_page.dart';
class EditPage extends StatefulWidget {
  const EditPage({Key? key,this.id="",this.name="",this.price="",this.photo=""}) : super(key: key);
  final String id;
  final String name;
  final String price;
  final String photo;
  @override
  State<EditPage> createState() => _EditPageState();
}

class _EditPageState extends State<EditPage> {
  final _productNameCtrl = TextEditingController();
  final _productPriceCtrl = TextEditingController();
  final _productPhotoCtrl = TextEditingController();
  @override
  void initState(){
    super.initState();
    _productNameCtrl.text = this.widget.name;
    _productPriceCtrl.text = this.widget.price;
    _productPhotoCtrl.text = this.widget.photo;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit product'),
        leading: new IconButton(
          icon: new Icon(Icons.ac_unit),
          //onPressed: () => Navigator.of(context).pop(),
          onPressed: (){
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => HomePage()));
          },
        ),
      ),

      body: Center(
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              TextField(
                controller: _productNameCtrl,
                decoration: InputDecoration(hintText: 'Name'),
              ),
              TextField(

                controller: _productPriceCtrl,
                decoration: InputDecoration(hintText: 'Price'),
                keyboardType: TextInputType.number,
              ),
              TextField(
                controller: _productPhotoCtrl,
                decoration: InputDecoration(hintText: 'Photo'),
              ),
              RaisedButton(
                child: Text(
                  'SAVE',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
                color: Colors.purple,
                onPressed: () {
                  final body = {
                    "id": this.widget.id,
                    "name": _productNameCtrl.text,
                    "price": _productPriceCtrl.text,
                    "photo": _productPhotoCtrl.text,
                  };
                  RemoteService.updateProduct(body).then((success) {
                    if (success!) {
                      showDialog(
                        builder: (context) => AlertDialog(
                          title: Text('Data updated!!!'),
                          actions: <Widget>[
                            FlatButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: Text('OK'),
                            )
                          ],
                        ),
                        context: context,
                      );
                      return;
                    }else{
                      showDialog(
                        builder: (context) => AlertDialog(
                          title: Text('Error updating!!!'),
                          actions: <Widget>[
                            FlatButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: Text('OK'),
                            )
                          ],
                        ),
                        context: context,
                      );
                      return;
                    }
                  });
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
