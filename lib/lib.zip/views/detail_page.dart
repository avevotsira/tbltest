import 'package:flutter/material.dart';
import '../models/product.dart';
import '../services/remote_service.dart';
import 'edit_page.dart';
class DetailPage extends StatefulWidget {
  const DetailPage({Key? key,this.id="",this.name="",this.price="",this.photo=""}) : super(key: key);
  final String id;
  final String name;
  final String price;
  final String photo;
  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  Product? product;
  //print(product?.name);
  @override
  void initState(){
    super.initState();
    // fetch data from API
    //print(this.widget.id);
    //getData(this.widget.id);
    //print(product?.name);
  }
  getData(id) async {
    product = await RemoteService.getProductByID(id);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail product'),
        leading: new IconButton(
          icon: new Icon(Icons.ac_unit),
          //onPressed: () => Navigator.of(context).pop(),
          onPressed: (){
            //Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => HomePage()));
          },
        ),
      ),

      body: Center(
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              Text(
                "ID: ${this.widget.id}",
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
              Text(
                "Name: ${this.widget.name}",
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
              Text(
                "Price: ${this.widget.price}",
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
              Text(
                "Photo: ${this.widget.photo}",
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
              RaisedButton(
                child: Text(
                  'Back',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
                color: Colors.purple,
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
              RaisedButton(
                child: Text(
                  'Edit',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
                color: Colors.purple,
                onPressed: () {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) =>
                      EditPage(
                          id: this.widget.id,
                          name: this.widget.name,
                          price: this.widget.price,
                          photo: this.widget.photo)
                  )
                  );
                },

              ),
              RaisedButton(
                child: Text(
                  'Delete',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
                color: Colors.purple,
                onPressed: () {
                  RemoteService.deleteProduct(this.widget.id).then((success) {
                    if (success) {
                      showDialog(
                        builder: (context) => AlertDialog(
                          title: Text('Data deleted!!!'),
                          actions: <Widget>[
                            FlatButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: Text('OK'),
                            )
                          ],
                        ),
                        context: context,
                      );
                      return;
                    }else{
                      showDialog(
                        builder: (context) => AlertDialog(
                          title: Text('Error deleting!!!'),
                          actions: <Widget>[
                            FlatButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: Text('OK'),
                            )
                          ],
                        ),
                        context: context,
                      );
                      return;
                    }
                  });
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
