import 'dart:convert';
import '../models/product.dart';
import 'package:http/http.dart' as http;
class RemoteService{
  Future<List<Product>?> getProducts() async{
    var client = http.Client();
    var uri = Uri.parse('http://10.0.2.2/www/api_android/index.php');
    var response = await client.get(uri);
    if(response.statusCode == 200){
      var json = response.body;
      return productsFromJson(json);
    }
  }
  static Future<List<Product>?> searchProducts(name) async{
    var client = http.Client();
    var uri = Uri.parse('http://10.0.2.2/www/api_android/search.php?name='+name);
    var response = await client.get(uri);
    if(response.statusCode == 200){
      var json = response.body;
      return productsFromJson(json);
    }
  }
  static Future<Product?> getProductByID(id) async{
    final body = {
      'id': id.toString(),
    };
    var client = http.Client();
    var uri = Uri.parse('http://10.0.2.2/www/api_android/detail.php');
    var response = await client.post(uri,body:body);
    if(response.statusCode == 200){
      var json = response.body;
      return productFromJson(json);
    }
  }

  static Future<bool> addProduct(body) async {
    final response = await http.post(Uri.parse('http://10.0.2.2/www/api_android/create.php'), body: body);
    if (response.statusCode == 200) {
      return true;
    } else {
      return false;
    }
  }
  static Future<bool> deleteProduct(id) async {
    final body = {
      'id': id.toString(),
    };
    final response = await http.post(Uri.parse('http://10.0.2.2/www/api_android/delete.php'),body:body);
    if (response.statusCode == 200) {
      return true;
    } else {
      return false;
    }
  }
  static Future<bool?> updateProduct(body) async {
    final response = await http.post(Uri.parse('http://10.0.2.2/www/api_android/update.php'), body: body);
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      return data["success"];
    }
  }
}